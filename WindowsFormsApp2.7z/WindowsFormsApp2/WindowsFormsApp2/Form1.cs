﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// int по x,y отвечает за выборку персонажа/определяет чей ход
        /// l ничья
        /// int z и n для определения победителя
        /// </summary>
        int x = 1;
        int y = 1;

        int l = 0;

        int z1, z2, z3, z4, z5, z6, z7, z8, z9;

        int n1, n2, n3, n4, n5, n6, n7, n8, n9;
        /// <summary>
        /// Кнопка 1 = Рик
        /// Кнопка 2 = Вудпекер
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            x = 1;
            panel1.Visible = false;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            x = 2;
            panel1.Visible = false;
        }
        private void Rick()
        {
            MessageBox.Show("Победа Рика");
            panel1.Visible = true;
            l = l - 1;
            Application.Restart();
        }
        private void Woodpecker()
        {
            MessageBox.Show("Победа Вудпекера");
            panel1.Visible = true;
            l = l - 1;
            Application.Restart();
        }
        private void VS()
        {
            MessageBox.Show("Ничья");
            panel1.Visible = true;
            Application.Restart();
        }
        /// <summary>
        /// Проверка победителя, поле 3х3
        /// </summary>
        private void woof()
        {
          /*y*/  if (z1 == 1 & z2 == 1 & z3 == 1) { Rick(); } 
          /*y*/  else if (z4 == 1 & z5 == 1 & z6 == 1) { Rick(); }
          /*y*/  else if (z7 == 1 & z8 == 1 & z9 == 1) { Rick(); }
          ///////////////////////////////////////////////////
          /*x*/  else if (z1 == 1 & z4 == 1 & z7 == 1) { Rick(); }
          /*x*/  else if (z2 == 1 & z5 == 1 & z8 == 1) { Rick(); }
          /*x*/  else if (z3 == 1 & z6 == 1 & z9 == 1) { Rick(); }
          ///////////////////////////////////////////////////
          /*xy*/  else if (z1 == 1 & z5 == 1 & z9 == 1) { Rick(); }
          /*xy*/  else if (z3 == 1 & z5 == 1 & z7 == 1) { Rick(); }
          ////////////////////////////////////////////////////
            /*x*/ else if (n1 == 1 & n2 == 1 & n3 == 1) { Woodpecker(); }
            /*x*/ else if (n4 == 1 & n5 == 1 & n6 == 1) { Woodpecker(); }
            /*x*/ else if (n7 == 1 & n8 == 1 & n9 == 1) { Woodpecker(); }
            ////////////////////////////////////////////////////////
            /*y*/ else if (n1 == 1 & n4 == 1 & n7 == 1) { Woodpecker(); }
            /*y*/ else if (n2 == 1 & n5 == 1 & n8 == 1) { Woodpecker(); }
            /*y*/ else if (n3 == 1 & n6 == 1 & n9 == 1) { Woodpecker(); }
            ////////////////////////////////////////////////////////
            /*xy*/ else if (n1 == 1 & n5 == 1 & n9 == 1) { Woodpecker(); }
            /*xy*/ else if (n3 == 1 & n5 == 1 & n7 == 1) { Woodpecker(); }     
            /////////////////////////////////////////////////////////
              /*9*/ else if (l == 9) { VS(); }
        }
        /// <summary>
        /// Проверка чей ход
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (x == 1)
            {
                x = x + y;
                z1 = z1 + 1;
                l = l + 1;
                pictureBox1.Image = Properties.Resources.icons8_rick_sanchez_48;
                pictureBox1.Enabled = false; woof();
                Console.WriteLine(x);
            }
            else
            {
                x = x - y;
                n1 = n1 + 1;
                l = l + 1;
                pictureBox1.Image = Properties.Resources.icons8_woody_woodpecker_48;
                pictureBox1.Enabled = false; woof();
                Console.WriteLine(x);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (x == 1)
            {
                x = x + y;
                z2 = z2 + 1;
                l = l + 1;
                pictureBox2.Image = Properties.Resources.icons8_rick_sanchez_48;
                pictureBox2.Enabled = false; woof();
                Console.WriteLine(x);
            }
            else
            {
                x = x - y;
                n2 = n2 + 1;
                l = l + 1;
                pictureBox2.Image = Properties.Resources.icons8_woody_woodpecker_48;
                pictureBox2.Enabled = false; woof();
                Console.WriteLine(x);
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (x == 1)
            {
                x = x + y;
                z3 = z3 + 1;
                l = l + 1;
                pictureBox3.Image = Properties.Resources.icons8_rick_sanchez_48;
                pictureBox3.Enabled = false; woof();
            }
            else
            {
                x = x - y;
                n3 = n3 + 1;
                l = l + 1;
                pictureBox3.Image = Properties.Resources.icons8_woody_woodpecker_48;
                pictureBox3.Enabled = false; woof();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (x == 1)
            {
                x = x + y;
                z4 = z4 + 1;
                l = l + 1;
                pictureBox4.Image = Properties.Resources.icons8_rick_sanchez_48;
                pictureBox4.Enabled = false; woof();
            }
            else
            {
                x = x - y;
                n4 = n4 + 1;
                l = l + 1;
                pictureBox4.Image = Properties.Resources.icons8_woody_woodpecker_48;
                pictureBox4.Enabled = false; woof();
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (x == 1)
            {
                x = x + y;
                z5 = z5 + 1;
                l = l + 1;
                pictureBox5.Image = Properties.Resources.icons8_rick_sanchez_48;
                pictureBox5.Enabled = false; woof();
            }
            else
            {
                x = x - y;
                n5 = n5 + 1;
                l = l + 1;
                pictureBox5.Image = Properties.Resources.icons8_woody_woodpecker_48;
                pictureBox5.Enabled = false; woof();
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            if (x == 1)
            {
                x = x + y;
                z6 = z6 + 1;
                l = l + 1;
                pictureBox6.Image = Properties.Resources.icons8_rick_sanchez_48;
                pictureBox6.Enabled = false; woof();
            }
            else
            {
                x = x - y;
                n6 = n6 + 1;
                l = l + 1;
                pictureBox6.Image = Properties.Resources.icons8_woody_woodpecker_48;
                pictureBox6.Enabled = false; woof();
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (x == 1)
            {
                x = x + y;
                z7 = z7 + 1;
                l = l + 1;
                pictureBox7.Image = Properties.Resources.icons8_rick_sanchez_48;
                pictureBox7.Enabled = false; woof();
            }
            else
            {
                x = x - y;
                n7 = n7 + 1;
                l = l + 1;
                pictureBox7.Image = Properties.Resources.icons8_woody_woodpecker_48;
                pictureBox7.Enabled = false; woof();
            }
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (x == 1)
            {
                x = x + y;
                z8= z8 + 1;
                l = l + 1;
                pictureBox8.Image = Properties.Resources.icons8_rick_sanchez_48;
                pictureBox8.Enabled = false; woof();
            }
            else
            {
                x = x - y;
                n8 = n8 + 1;
                l = l + 1;
                pictureBox8.Image = Properties.Resources.icons8_woody_woodpecker_48;
                pictureBox8.Enabled = false; woof();
            }
        }
        private void pictureBox9_Click(object sender, EventArgs e)
        {
            if (x == 1)
            {
                x = x + y;
                z9 = z9 + 1;
                l = l + 1;
                pictureBox9.Image = Properties.Resources.icons8_rick_sanchez_48;
                pictureBox9.Enabled = false; woof();
            }
            else
            {
                x = x - y;
                n9 = n9 + 1;
                l = l + 1;
                pictureBox9.Image = Properties.Resources.icons8_woody_woodpecker_48;
                pictureBox9.Enabled = false; woof();
            }
        }
    }           
}
